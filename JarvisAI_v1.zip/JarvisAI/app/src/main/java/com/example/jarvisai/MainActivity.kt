package com.example.jarvisai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.jarvisai.databinding.ActivityMainBinding
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var binding: ActivityMainBinding
    private var speechRecognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private val client = OkHttpClient()
    private val conversation = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        tts = TextToSpeech(this, this)

        val prefs = getSharedPreferences("jarvis_prefs", MODE_PRIVATE)
        binding.apiKeyInput.setText(prefs.getString("api_key", ""))

        requestNeededPermissions()

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(recognitionListener)
        } else {
            binding.statusText.text = "เครื่องนี้ไม่รองรับการรู้จำเสียง"
        }

        binding.talkButton.setOnClickListener {
            val key = binding.apiKeyInput.text.toString().trim()
            if (key.isEmpty()) {
                Toast.makeText(this, "กรุณาใส่ Claude API key ก่อนครับ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("api_key", key).apply()
            startListening()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("th", "TH"))
            val thaiAvailable = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!thaiAvailable) {
                Toast.makeText(
                    this,
                    "เครื่องนี้ยังไม่มีเสียงพูดภาษาไทย ลองติดตั้งเพิ่มในตั้งค่าเสียงของเครื่อง",
                    Toast.LENGTH_LONG
                ).show()
            }
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    runOnUiThread { binding.statusText.text = "พร้อมใช้งาน" }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    runOnUiThread { binding.statusText.text = "พร้อมใช้งาน" }
                }
            })
        }
    }

    private fun requestNeededPermissions() {
        val toRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            toRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            toRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (toRequest.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, toRequest.toTypedArray(), 100)
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "ต้องอนุญาตใช้ไมโครโฟนก่อนครับ", Toast.LENGTH_SHORT).show()
            requestNeededPermissions()
            return
        }
        binding.statusText.text = "กำลังฟัง..."
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH")
        }
        speechRecognizer?.startListening(intent)
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            binding.statusText.text = "กำลังคิด..."
        }
        override fun onError(error: Int) {
            binding.statusText.text = "พร้อมใช้งาน"
            Toast.makeText(
                this@MainActivity,
                "ไม่ได้ยินหรือเกิดข้อผิดพลาด ลองใหม่อีกครั้งครับ",
                Toast.LENGTH_SHORT
            ).show()
        }
        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()
            if (text.isNullOrBlank()) {
                binding.statusText.text = "พร้อมใช้งาน"
                return
            }
            appendConversation("คุณ: $text")
            sendToClaude(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun appendConversation(line: String) {
        conversation.append(line).append("\n\n")
        binding.conversationText.text = conversation.toString()
    }

    private fun sendToClaude(userText: String) {
        val apiKey = binding.apiKeyInput.text.toString().trim()

        val json = JSONObject().apply {
            put("model", "claude-sonnet-5")
            put("max_tokens", 1024)
            put(
                "system",
                "คุณคือ JARVIS ผู้ช่วย AI ส่วนตัวที่พูดภาษาไทย ตอบกระชับ เป็นกันเอง " +
                    "มีความกวนหรือแซวเบาๆ ได้บ้างเวลาคุยเล่น แต่จริงจังและช่วยเหลือเต็มที่เวลาผู้ใช้ต้องการความช่วยเหลือจริงๆ"
            )
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", userText)
                })
            })
        }

        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    binding.statusText.text = "พร้อมใช้งาน"
                    Toast.makeText(
                        this@MainActivity,
                        "เชื่อมต่อ AI ไม่ได้ เช็คอินเทอร์เน็ตหรือ API key",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val bodyStr = response.body?.string() ?: ""
                runOnUiThread {
                    if (!response.isSuccessful) {
                        binding.statusText.text = "พร้อมใช้งาน"
                        Toast.makeText(
                            this@MainActivity,
                            "AI ตอบกลับผิดพลาด: ${response.code}",
                            Toast.LENGTH_LONG
                        ).show()
                        return@runOnUiThread
                    }
                    try {
                        val resJson = JSONObject(bodyStr)
                        val contentArray = resJson.getJSONArray("content")
                        val answer = contentArray.getJSONObject(0).getString("text")
                        appendConversation("JARVIS: $answer")
                        speak(answer)
                    } catch (e: Exception) {
                        binding.statusText.text = "พร้อมใช้งาน"
                        Toast.makeText(
                            this@MainActivity,
                            "อ่านคำตอบจาก AI ไม่ได้",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        })
    }

    private fun speak(text: String) {
        binding.statusText.text = "กำลังพูด..."
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
